# Jak wrzucić projekt na GitHub przez przeglądarkę

Repozytorium `kamilzogala-png/comic-reading-guides` już istnieje. Najprościej wgrać projekt przez stronę GitHub.

## Krok 1. Rozpakuj ZIP

1. Pobierz plik `comic-reading-guides.zip`.
2. Rozpakuj go na komputerze.
3. Otwórz folder `comic-reading-guides`.
4. Sprawdź, czy bezpośrednio w nim widzisz `README.md`, `package.json`, `src`, `data`, `docs` i `scripts`.

Ważne: nie wgrywaj samego pliku ZIP do repozytorium i nie twórz dodatkowego, zagnieżdżonego folderu `comic-reading-guides/comic-reading-guides`.

## Krok 2. Otwórz repozytorium

Wejdź na:

https://github.com/kamilzogala-png/comic-reading-guides

Upewnij się, że jesteś zalogowany na właściwe konto.

## Krok 3. Dodaj pliki

1. Kliknij **Add file**.
2. Wybierz **Upload files**.
3. Otwórz rozpakowany folder projektu na komputerze.
4. Zaznacz całą jego zawartość (pliki i foldery `src`, `data`, `docs`, `scripts`).
5. Przeciągnij zaznaczone elementy na pole uploadu GitHuba. Możesz też użyć selektora plików.
6. Poczekaj, aż wszystkie pliki zakończą przesyłanie.

Jeśli interfejs nie pozwala wybrać folderów, otwórz foldery `src`, `data`, `docs`, `scripts` i wgraj ich zawartość, zachowując strukturę katalogów. Najwygodniej zrobić to z komputera, nie z telefonu.

## Krok 4. Zapisz zmiany

Na dole strony:

1. W polu commit message wpisz `Add Comic Reading Guides starter project`.
2. Zostaw zaznaczone **Commit directly to the main branch**.
3. Kliknij **Commit changes**.

## Krok 5. Sprawdź wynik

Po powrocie do strony głównej repozytorium powinieneś widzieć m.in. `README.md`, `package.json`, `src/`, `data/`, `docs/` i `scripts/`.

Link do repozytorium:

https://github.com/kamilzogala-png/comic-reading-guides

## Co dalej

To jest starter logiki i danych, a nie gotowa do instalacji paczka Paperback. Następny etap to potwierdzenie oficjalnego API Paperback 0.9 i dopiero wtedy dodanie manifestu, ekranów rozszerzenia oraz integracji otwierania komiksów/progresu, jeśli SDK to umożliwia.
